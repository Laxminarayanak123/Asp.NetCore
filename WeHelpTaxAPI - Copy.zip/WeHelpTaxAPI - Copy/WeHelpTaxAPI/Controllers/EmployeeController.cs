﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Linq;
using WeHelpTaxAPI.Model;
using System;

namespace WeHelpTaxAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EmployeeController : ControllerBase
    {
        private readonly taxPayerApplicationContext taxContext;

        public EmployeeController(taxPayerApplicationContext tax)
        {
            taxContext = tax;
        }
        [HttpGet]
        public IActionResult Index()
        {
            List<Employee> employee = taxContext.Employee.ToList();
            
            if(employee.Count<1)
            {
                return StatusCode(204);
            }
            else
            {
                return StatusCode(200, employee);
            }
           
        }

        [HttpGet("GetEmpDetails/{EmployeeId}")]
        public IActionResult GetEmployeeDetail(int EmployeeId)
        {
            Employee employee = taxContext.Employee.Find(EmployeeId);
            if (employee == null)
            {
                return StatusCode(404, "Course Id Not available");
            }
            else
            {
                return StatusCode(200, employee);
            }

        }

        [HttpGet("DeleteEmp/{EmployeeId}")]
        public IActionResult DeleteEmployee(int EmployeeId)
        {
            Employee employee = taxContext.Employee.Find(EmployeeId);
            if (employee == null)
            {
                return StatusCode(404, "Course Id not available");
            }
            else
            {
                taxContext.Employee.Remove(employee);
                taxContext.SaveChanges();
                return Ok();
            }

        }


        [HttpPost("AddEmp")]
        public IActionResult AddNewEmployee([FromBody]Employee employee)
        {
            if (employee==null)
            {
                taxContext.Employee.Add(employee);
                taxContext.SaveChanges();
                return Ok();
            }
            else
            {
                return StatusCode(403);
            }

        }
    }
}
