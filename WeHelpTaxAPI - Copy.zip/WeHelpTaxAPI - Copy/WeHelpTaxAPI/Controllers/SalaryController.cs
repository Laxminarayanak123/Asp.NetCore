﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using WeHelpTaxAPI.Model;

namespace WeHelpTaxAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SalaryController : ControllerBase
    {
        private readonly taxPayerApplicationContext salContext;

        public SalaryController(taxPayerApplicationContext tax)
        {
            salContext = tax;
        }
        [HttpGet]
        public IActionResult Index()
        {
            List<Salary> salary = salContext.Salary.ToList();

            if (salary.Count < 1)
            {
                return StatusCode(204);
            }
            else
            {
                return StatusCode(200, salary);
            }

        }

        [HttpGet("GetSal/{EmployeeId}")]
        public IActionResult GetEmployeeDetail(int EmployeeId)
        {
            Employee employee = salContext.Employee.Find(EmployeeId);
            if (employee == null)
            {
                return StatusCode(404, "Course Id Not available");
            }
            else
            {
                return StatusCode(200, employee);
            }

        }

        [HttpGet("DeleteEmp/{EmployeeId}")]
        public IActionResult DeleteEmployee(int EmployeeId)
        {
            Employee employee = salContext.Employee.Find(EmployeeId);
            if (employee == null)
            {
                return StatusCode(404, "Course Id not available");
            }
            else
            {
                salContext.Employee.Remove(employee);
                salContext.SaveChanges();
                return Ok();
            }

        }


        [HttpPost("AddEmp")]
        public IActionResult AddNewEmployee([FromBody] Employee employee)
        {
            if (employee == null)
            {
                salContext.Employee.Add(employee);
                salContext.SaveChanges();
                return Ok();
            }
            else
            {
                return StatusCode(403);
            }
        }
    }
}
