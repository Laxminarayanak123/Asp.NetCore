﻿//using JWTWebAuthentication.Repository;
//using Microsoft.AspNetCore.Authorization;
//using Microsoft.AspNetCore.Http;
//using Microsoft.AspNetCore.Mvc;
//using Microsoft.Extensions.Configuration;
//using WeHelpTaxAPI.Model;

//namespace WeHelpTaxAPI.Repository
//{
//    [Route("api/[controller]")]
//    [ApiController]
//    public class ValuesController : ControllerBase
//    {
//        private readonly taxPayerApplicationContext taxContext;

//        private readonly IConfiguration iconfiguration;

//        public ValuesController(taxPayerApplicationContext tax, IConfiguration iconfiguration)
//        {
//            this.iconfiguration = iconfiguration;

//            taxContext = tax;
//        }
        
//    }
//}
